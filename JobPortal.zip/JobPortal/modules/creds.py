user_pwd = "Vansh@123"  # use your MySQL Password
